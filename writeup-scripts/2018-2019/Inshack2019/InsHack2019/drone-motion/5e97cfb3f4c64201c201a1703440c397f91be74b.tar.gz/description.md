We intercepted a drone flying above a restricted area and retrieved a [log](https://static.ctf.insecurity-insa.fr/5e97cfb3f4c64201c201a1703440c397f91be74b.tar.gz) from its memory card.

Help us find out what this drone was doing above our heads!

Flag must match the regex: `INSA\{[a-z0-9]+\}`
