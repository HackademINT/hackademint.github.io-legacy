[Buy an encrypted flag, get a (almost intact) prime factor for free !](https://static.ctf.insecurity-insa.fr/595437e42ea3951e8ed4ecda16141f017f3ba36b.tar.gz)

You can find a harder version of this challenge in the Programming category.