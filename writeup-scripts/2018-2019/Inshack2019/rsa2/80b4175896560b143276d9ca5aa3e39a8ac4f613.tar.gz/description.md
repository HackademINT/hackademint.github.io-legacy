If not done already, you should probably attempt Part 1 of this challenge (in the Crypto category).

[Same player, shoot again.](https://static.ctf.insecurity-insa.fr/80b4175896560b143276d9ca5aa3e39a8ac4f613.tar.gz)