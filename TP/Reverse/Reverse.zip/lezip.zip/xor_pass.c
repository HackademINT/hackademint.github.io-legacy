#include<stdio.h>
#include<string.h>

void main() {
	char var1[34]="H`aheacjAG^pt=|8ukMwK|U~GT*uOt-jR\\";
	puts("Enter password :");
	char var2[34];
	fgets(var2, 0x22, stdin);
	int win = 1;
	int compteur = 0;
	
	for (compteur=0;compteur <= 33; compteur ++)
	{

		if((var1[compteur]^var2[compteur]) != compteur){
			win = 0;
			break;
		}
	}

	if (win == 1)
	{
	    printf("GG!\n"); 
	}
	else
	{
	    printf("NOPE\n");  
	} 
}

