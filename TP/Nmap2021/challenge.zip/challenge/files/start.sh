#!/bin/bash

cd /root/publicserver
python flaskserver.py &
cd /root/privateserver
python -m SimpleHTTPServer 64321 &
service ssh start
service mysql start
service xinetd start
service tftpd-hpa start
tail -f /dev/null
