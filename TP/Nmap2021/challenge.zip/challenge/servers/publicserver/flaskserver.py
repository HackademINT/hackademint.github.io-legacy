from flask import Flask, make_response
app = Flask(__name__)


@app.route('/')
def hello():
    return 'This is my public server. Nothing to see here, go away !'

@app.route('/admin.html')
def admin():
	return 'What did you expect ?! ;-P'

@app.after_request
def apply_caching(response):
    response.headers['Server'] = 'Werkzeug/1.0.1 Python/HackademINT_D0nT_Y0u_l00K_4t_mY_v3rs10N'
    return response

if __name__ == '__main__':
    app.run(port=80, host='0.0.0.0')

